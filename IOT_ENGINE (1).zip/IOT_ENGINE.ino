#include <WiFi.h>
#include <ThingSpeak.h>
#include "DHT.h"
#include <Wire.h>
#include <MPU6050.h>

#define DHTPIN 4          // DHT data pin
#define DHTTYPE DHT11     // Or use DHT22
#define VIBRATION_PIN 34  // Digital pin for vibration sensor

DHT dht(DHTPIN, DHTTYPE);
MPU6050 mpu(Wire);

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

WiFiClient client;

// ThingSpeak settings
unsigned long myChannelNumber = YOUR_CHANNEL_NUMBER;   // Replace with your channel number
const char* myWriteAPIKey = "YOUR_WRITE_API_KEY";

void setup() {
  Serial.begin(115200);
  
  pinMode(VIBRATION_PIN, INPUT);
  dht.begin();
  Wire.begin();  // I2C init
  mpu.begin();

  // Connect to WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");

  ThingSpeak.begin(client);
}

void loop() {
  // Read temperature and humidity
  float temp = dht.readTemperature();
  float humidity = dht.readHumidity();

  // Read vibration sensor
  int vibrationState = digitalRead(VIBRATION_PIN);

  // Read MPU6050 values
  mpu.update();
  float ax = mpu.getAccX();
  float ay = mpu.getAccY();
  float az = mpu.getAccZ();

  // Print to Serial Monitor
  Serial.println("----- Sensor Readings -----");
  Serial.print("Temperature: "); Serial.print(temp); Serial.println(" °C");
  Serial.print("Humidity: "); Serial.print(humidity); Serial.println(" %");
  Serial.print("Vibration Detected: "); Serial.println(vibrationState == HIGH ? "YES" : "NO");
  Serial.print("Accel X: "); Serial.println(ax);
  Serial.print("Accel Y: "); Serial.println(ay);
  Serial.print("Accel Z: "); Serial.println(az);

  // Send to ThingSpeak
  ThingSpeak.setField(1, temp);
  ThingSpeak.setField(2, humidity);
  ThingSpeak.setField(3, vibrationState);
  ThingSpeak.setField(4, ax);
  ThingSpeak.setField(5, ay);
  ThingSpeak.setField(6, az);

  int x = ThingSpeak.writeFields(myChannelNumber, myWriteAPIKey);

  if (x == 200) {
    Serial.println("Data sent to ThingSpeak successfully");
  } else {
    Serial.print("Failed to send data. HTTP error code: "); Serial.println(x);
  }

  delay(15000);
}
